MagPress L1 (L1-A) - DXF cutting profiles, R12, mm, 1:1. One file per cut part.
No part is bent: every file is a flat profile to cut (laser / plasma / waterjet for the frame plates; wire-EDM for the hardened die openings) and then machine as the PDF drawing says.
Layers: OUTLINE (cut), HOLES (through holes, true size), TAP_DRILL (tap drill size - tap after cutting), COUNTERBORE (machine to depth), POCKET (blind pocket outline), SPOT (dimple), TAPER_BOTTOM (cup ring: bottom of the 18 deg taper), NOTES (part label).
Plate parts: plan view, +Y (back of the press) up. Profile parts (cheek, clevis, lever plate, link): side profile as cut.
Material sizes are ASSUMED (see sheet L-003): parts marked MAT may change by a few tenths before manufacture.
The PDF drawings govern.
