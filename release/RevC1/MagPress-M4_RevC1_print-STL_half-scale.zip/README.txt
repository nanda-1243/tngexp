MagPress M4 Rev C.1 - every part as its own STL file, half scale (50 %), fits a 256 mm bed.

Folders: 01 frame, 02 die table, 03 press drive (ram, crown, lever, links, pins), 04 universal die,
05 hardware that comes with every size kit, 06-09 the four size kits (5050 = 50 x 50, 6363 = 63.5 x 63.5,
5380 = 53 x 80, 6590 = 65 x 90). Pick the kits you want; one kit is enough to see how everything fits.

The number at the end of each file name is how many to print for one press (folder 05: per kit).
Files: 99. Pieces for one press with all four kits: 238.

MP-xxx files are machined parts (drawing numbers). BUY-xx files are bought hardware (screws, pins, springs,
bushings): print them for looks, or use real ones at full size and skip them.

Units mm. Parts lie flat or stand on one end, ready to slice. Holes and pins are at their true size, so
printed pins will not go into printed holes: use the slicer's hole compensation (+0.15 to +0.3 mm) or print
pins and screws at 97-98 %. Springs are shown at their installed length.

Parts that need more than a 220 x 220 mm bed or 250 mm height at this scale (as laid out in the file, X x Y x height):
  MP-101_base-plate  230 x 235 x 8 mm
  MP-102-F_guide-rail-front  230 x 7 x 6 mm
  MP-102-B_guide-rail-back  230 x 7 x 6 mm
  MP-103-F_keeper-strip-front  230 x 10 x 2 mm
  MP-103-B_keeper-strip-back  230 x 10 x 2 mm

Made by models/make_print_pack.py from models/stl and models/obj. 3D views of how the parts fit:
models/assembly/ and the assembly manual (release/MagPress-M4_Assembly-Manual_RevC1.pdf).
