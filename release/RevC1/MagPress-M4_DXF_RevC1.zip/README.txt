MagPress M4 Rev C.1 - DXF profiles (R12, mm, 1:1).
Layers: OUTLINE (cut), HOLES (through holes, true size), TAP_DRILL (tap drill size - tap after cutting),
COUNTERBORE (c'bore diameter - machine to depth per drawing), POCKET (blind pocket outline), SPOT.
Plan views: X right, front of the press at the bottom (crown/ram: front to the right).
Die-set files carry the size code: 5050, 6363, 5380, 6590; universal parts are marked _universal. The PDF drawings govern.
